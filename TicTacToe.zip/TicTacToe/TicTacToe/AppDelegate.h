//
//  AppDelegate.h
//  TicTacToe
//
//  Created by Shiv Patel on 10/26/16.
//  Copyright © 2016 Shiv Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

