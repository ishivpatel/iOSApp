//
//  ViewController.m
//  TicTacToe
//
//  Created by Shiv Patel on 10/26/16.
//  Copyright © 2016 Shiv Patel. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    oImg = [UIImage imageNamed:@"o_img"];
    xImg = [UIImage imageNamed:@"x_img"];
    

    
    playerToken = 1;
    
    [self.whoseTurn setText:@"Player X Starts"];
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)buttonReset:(id)sender {
    
    [self resetBoard];
}

-(void) updatePlayer{
    
    if(playerToken == 1) {
        if([self checkForWin] == TRUE){
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Game Over"
                                                            message:@"Player X Won!!"
                                                           delegate:nil
                                                  cancelButtonTitle:@"New Game"
                                                  otherButtonTitles:nil];
            [alert show];
            
            self.whoseTurn.text = @"Player X Won";
            [self resetBoard];
        }
        else{
        playerToken = 2;
        self.whoseTurn.text = @"Player O's Turn";
        }
    }
    else if(playerToken == 2) {
        if([self checkForWin] == TRUE){
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Game Over"
                                                            message:@"Player O Won!!"
                                                           delegate:nil
                                                  cancelButtonTitle:@"New Game"
                                                  otherButtonTitles:nil];
            [alert show];
           self.whoseTurn.text =@"Player O Won";
            [self resetBoard];
        }
        else{
        playerToken = 1;
        self.whoseTurn.text =@"Player X's Turn";
        }
    }
    if(playerToken==3){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Game Over"
                                                        message:@"it was a Tie."
                                                       delegate:nil
                                              cancelButtonTitle:@"New Game"
                                              otherButtonTitles:nil];
        [alert show];
        [self resetBoard];
    }
}

-(void) resetBoard{
    [self.s1 setImage:NULL];
    [self.s2 setImage:NULL];
    [self.s3 setImage:NULL];
    [self.s4 setImage:NULL];
    [self.s5 setImage:NULL];
    [self.s6 setImage:NULL];
    [self.s7 setImage:NULL];
    [self.s8 setImage:NULL];
    [self.s9 setImage:NULL];
    
    playerToken =1;
    self.whoseTurn.text = xturn;
}
-(void) checkForTie{
    if((self.s1.image!=NULL) && (self.s2.image!=NULL) && (self.s3.image!=NULL) && (self.s4.image!=NULL)
      && (self.s5.image!=NULL) && (self.s6.image!=NULL) && (self.s7.image!=NULL) && (self.s8.image!=NULL)
    && (self.s9.image!=NULL)){
     playerToken=3;
    [self updatePlayer];
    }
}

-(BOOL) checkForWin{
    
    [self checkForTie];
    
    //Horizontal
    if((self.s1.image == self.s2.image) && (self.s1.image == self.s3.image) && (self.s1.image!= NULL)){
        return YES;
       }
    if((self.s4.image == self.s5.image) && (self.s6.image == self.s4.image) && (self.s4.image!= NULL)){
        return YES;
    }
    if((self.s7.image == self.s8.image) && (self.s9.image == self.s7.image) && (self.s7.image!= NULL)){
        return YES;
    }
    
    //Vertical
    if((self.s1.image == self.s4.image) && (self.s7.image == self.s1.image) && (self.s1.image!= NULL)){
        return YES;
    }
    if((self.s2.image == self.s5.image) && (self.s8.image == self.s2.image) && (self.s2.image!= NULL)){
        return YES;
    }
    if((self.s3.image == self.s6.image) && (self.s9.image == self.s3.image) && (self.s3.image!= NULL)){
        return YES;
    }
   
    //Diagnol
    if((self.s1.image == self.s5.image) && (self.s9.image == self.s1.image) && (self.s1.image!= NULL)){
        return YES;
    }
    if((self.s3.image == self.s5.image) && (self.s7.image == self.s3.image) && (self.s3.image!= NULL)){
        return YES;
    }
    
   
       // return YES;
    //}
    
    return NO;
}


-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [[event allTouches] anyObject];
    
    if(CGRectContainsPoint([self.s1 frame], [touch locationInView:self.view])){
        if(self.s1.image == NULL){
        if(playerToken==1)[self.s1 setImage:xImg];
        if(playerToken==2)[self.s1 setImage:oImg];
        }
    }
    //s2 touch
    
    if(CGRectContainsPoint([self.s2 frame], [touch locationInView:self.view])){
        if(self.s2.image == NULL){
            if(playerToken==1)[self.s2 setImage:xImg];
            if(playerToken==2)[self.s2 setImage:oImg];
        }
    }
    
    //s3 touch
    if(CGRectContainsPoint([self.s3 frame], [touch locationInView:self.view])){
        if(self.s3.image == NULL){
            if(playerToken==1)[self.s3 setImage:xImg];
            if(playerToken==2)[self.s3 setImage:oImg];
        }
    }
    
    //s4 touch
    if(CGRectContainsPoint([self.s4 frame], [touch locationInView:self.view])){
        if(self.s4.image == NULL){
            if(playerToken==1)[self.s4 setImage:xImg];
            if(playerToken==2)[self.s4 setImage:oImg];
        }
     
    }
    
    //s5 touch
    if(CGRectContainsPoint([self.s5 frame], [touch locationInView:self.view])){
        if(self.s5.image == NULL){
            if(playerToken==1)[self.s5 setImage:xImg];
            if(playerToken==2)[self.s5 setImage:oImg];
        }
    }
    
    //s6 touch
    if(CGRectContainsPoint([self.s6 frame], [touch locationInView:self.view])){
        if(self.s6.image == NULL){
            if(playerToken==1)[self.s6 setImage:xImg];
            if(playerToken==2)[self.s6 setImage:oImg];
        }
    }
    
    //s7 touch
    if(CGRectContainsPoint([self.s7 frame], [touch locationInView:self.view])){
        if(self.s7.image == NULL){
            if(playerToken==1)[self.s7 setImage:xImg];
            if(playerToken==2)[self.s7 setImage:oImg];
        }
    }
    
    //s8 touch
    if(CGRectContainsPoint([self.s8 frame], [touch locationInView:self.view])){
        if(self.s8.image == NULL){
            if(playerToken==1)[self.s8 setImage:xImg];
            if(playerToken==2)[self.s8 setImage:oImg];
        }
    }
    
    //s9 touch
    if(CGRectContainsPoint([self.s9 frame], [touch locationInView:self.view])){
        if(self.s9.image == NULL){
            if(playerToken==1)[self.s9 setImage:xImg];
            if(playerToken==2)[self.s9 setImage:oImg];
        }
    }
    
    [self updatePlayer];
}
@end
