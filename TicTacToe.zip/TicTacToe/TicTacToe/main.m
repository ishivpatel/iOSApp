//
//  main.m
//  TicTacToe
//
//  Created by Shiv Patel on 10/26/16.
//  Copyright © 2016 Shiv Patel. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
